package com.naehrwerte.app

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore

// Schreibt die automatische Sicherung als Datei, ohne Dialog:
//  "downloads": Downloads/MacroTrack (MediaStore, ab Android 10, keine Berechtigung nötig)
//  "folder": ein Ordner, den der Nutzer einmal gewählt hat (Storage Access Framework, z. B. ein Google-Drive-Ordner)
// Es bleiben die letzten 7 Dateien (MacroTrack-Sicherung-JJJJ-MM-TT.json, eine pro Tag).
// Rückgabe: "ok" oder eine Fehlermeldung; "nofolder" = der gewählte Ordner ist nicht mehr verfügbar.
object AutoBackup {
 const val PREFS = "autobackup"
 private const val KEEP = 7
 private const val MIME = "application/json"
 private const val REL = "Download/MacroTrack/"
 private val NAME = Regex("^MacroTrack-Sicherung-\\d{4}-\\d{2}-\\d{2}\\.json$")

 fun write(ctx: Context, mode: String, json: String, name: String): String {
  if (!NAME.matches(name)) return "Ungültiger Dateiname"
  return try {
   if (mode == "downloads") toDownloads(ctx, json, name)
   else if (mode == "folder") toFolder(ctx, json, name)
   else "Unbekannter Speicherort"
  } catch (e: Exception) {
   "Fehler: " + (e.message ?: e.javaClass.simpleName)
  }
 }

 // Anzeigename des gewählten Ordners (letzter Teil des Pfads)
 fun folderLabel(tree: Uri): String {
  return try {
   val id = DocumentsContract.getTreeDocumentId(tree)
   val last = id.substringAfterLast(':').substringAfterLast('/')
   if (last.isBlank()) "Hauptspeicher" else last
  } catch (e: Exception) {
   "Ordner"
  }
 }

 // ---- Downloads/MacroTrack
 private fun toDownloads(ctx: Context, json: String, name: String): String {
  if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
   return "Downloads geht erst ab Android 10. Bitte einen eigenen Ordner wählen."
  }
  val res = ctx.contentResolver
  var uri: Uri? = findDownload(ctx, name)
  if (uri == null) {
   val v = ContentValues()
   v.put(MediaStore.Downloads.DISPLAY_NAME, name)
   v.put(MediaStore.Downloads.MIME_TYPE, MIME)
   v.put(MediaStore.Downloads.RELATIVE_PATH, REL)
   uri = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
  }
  if (uri == null) return "Datei konnte nicht angelegt werden"
  val out = res.openOutputStream(uri, "wt") ?: return "Datei konnte nicht geschrieben werden"
  out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
  try {
   pruneDownloads(ctx)
  } catch (e: Exception) {
  }
  return "ok"
 }

 private fun findDownload(ctx: Context, name: String): Uri? {
  val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
  val c = ctx.contentResolver.query(
   coll,
   arrayOf(MediaStore.Downloads._ID),
   MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?",
   arrayOf(name, REL),
   null
  ) ?: return null
  try {
   if (c.moveToFirst()) return ContentUris.withAppendedId(coll, c.getLong(0))
  } finally {
   c.close()
  }
  return null
 }

 private fun pruneDownloads(ctx: Context) {
  val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
  val c = ctx.contentResolver.query(
   coll,
   arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME),
   MediaStore.Downloads.RELATIVE_PATH + "=?",
   arrayOf(REL),
   null
  ) ?: return
  val found = ArrayList<Pair<Long, String>>()
  try {
   while (c.moveToNext()) {
    val n = c.getString(1) ?: continue
    if (NAME.matches(n)) found.add(Pair(c.getLong(0), n))
   }
  } finally {
   c.close()
  }
  found.sortByDescending { it.second }
  for (i in KEEP until found.size) {
   try {
    ctx.contentResolver.delete(ContentUris.withAppendedId(coll, found[i].first), null, null)
   } catch (e: Exception) {
   }
  }
 }

 // ---- Ordner, den der Nutzer einmal gewählt hat
 private fun toFolder(ctx: Context, json: String, name: String): String {
  val saved = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("folder", null) ?: return "nofolder"
  val tree = Uri.parse(saved)
  val permitted = ctx.contentResolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission }
  if (!permitted) return "nofolder"
  val parentId = DocumentsContract.getTreeDocumentId(tree)
  val parent = DocumentsContract.buildDocumentUriUsingTree(tree, parentId)
  val kids = children(ctx, tree, parentId)
  var target: Uri? = null
  for (k in kids) {
   if (k.second == name) {
    target = DocumentsContract.buildDocumentUriUsingTree(tree, k.first)
    break
   }
  }
  if (target == null) target = DocumentsContract.createDocument(ctx.contentResolver, parent, MIME, name)
  if (target == null) return "Datei konnte nicht angelegt werden"
  val out = ctx.contentResolver.openOutputStream(target, "wt") ?: return "Datei konnte nicht geschrieben werden"
  out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
  try {
   // die neue Datei zählt mit: es bleiben KEEP - 1 ältere
   val old = kids.filter { NAME.matches(it.second) && it.second != name }.sortedByDescending { it.second }
   for (i in (KEEP - 1) until old.size) {
    DocumentsContract.deleteDocument(ctx.contentResolver, DocumentsContract.buildDocumentUriUsingTree(tree, old[i].first))
   }
  } catch (e: Exception) {
  }
  return "ok"
 }

 private fun children(ctx: Context, tree: Uri, parentId: String): List<Pair<String, String>> {
  val list = ArrayList<Pair<String, String>>()
  val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
  val c = ctx.contentResolver.query(
   uri,
   arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME),
   null,
   null,
   null
  ) ?: return list
  try {
   while (c.moveToNext()) {
    val id = c.getString(0) ?: continue
    val n = c.getString(1) ?: continue
    list.add(Pair(id, n))
   }
  } finally {
   c.close()
  }
  return list
 }
}
