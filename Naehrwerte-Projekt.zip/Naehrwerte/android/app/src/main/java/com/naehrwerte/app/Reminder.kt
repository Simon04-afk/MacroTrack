package com.naehrwerte.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.LocalDate
import java.util.Calendar

// Tägliche Erinnerung: AlarmManager (ungenau, braucht keine Sonderberechtigung) weckt den Receiver,
// der nur dann eine Benachrichtigung zeigt, wenn heute noch nichts eingetragen wurde.
object Reminder {
 const val PREFS = "reminder"
 const val CHANNEL = "daily_reminder"

 private fun pending(ctx: Context): PendingIntent =
  PendingIntent.getBroadcast(
   ctx, 7, Intent(ctx, ReminderReceiver::class.java),
   PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
  )

 fun schedule(ctx: Context, hour: Int, minute: Int) {
  val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
  val cal = Calendar.getInstance().apply {
   set(Calendar.HOUR_OF_DAY, hour)
   set(Calendar.MINUTE, minute)
   set(Calendar.SECOND, 0)
   set(Calendar.MILLISECOND, 0)
   if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
  }
  am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending(ctx))
 }

 fun cancel(ctx: Context) {
  val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
  am.cancel(pending(ctx))
 }

 // Nach Neustart des Handys wieder einplanen
 fun restore(ctx: Context) {
  val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
  if (p.getBoolean("on", false)) schedule(ctx, p.getInt("h", 19), p.getInt("m", 0)) else cancel(ctx)
 }
}

class ReminderReceiver : BroadcastReceiver() {
 override fun onReceive(ctx: Context, intent: Intent?) {
  val p = ctx.getSharedPreferences(Reminder.PREFS, Context.MODE_PRIVATE)
  if (!p.getBoolean("on", false)) return
  if (p.getString("logged", "") == LocalDate.now().toString()) return
  val nm = NotificationManagerCompat.from(ctx)
  if (!nm.areNotificationsEnabled()) return
  val channel = NotificationChannel(Reminder.CHANNEL, "Tägliche Erinnerung", NotificationManager.IMPORTANCE_DEFAULT)
  (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
  val open = PendingIntent.getActivity(
   ctx, 8, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
   PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
  )
  val n = NotificationCompat.Builder(ctx, Reminder.CHANNEL)
   .setSmallIcon(R.drawable.ic_stat_ring)
   .setContentTitle("MacroTrack")
   .setContentText("Du hast heute noch nichts eingetragen. Tippe, um deine Mahlzeiten zu loggen.")
   .setContentIntent(open)
   .setAutoCancel(true)
   .build()
  try {
   nm.notify(1001, n)
  } catch (e: SecurityException) {
  }
 }
}

class BootReceiver : BroadcastReceiver() {
 override fun onReceive(ctx: Context, intent: Intent?) {
  if (intent?.action == Intent.ACTION_BOOT_COMPLETED) Reminder.restore(ctx)
 }
}
