package com.naehrwerte.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
 private lateinit var web: WebView
 private var pending: PermissionRequest? = null
 private var fileCallback: ValueCallback<Array<Uri>>? = null
 private var pendingBackup: String? = null

 // Datei auswählen (Backup importieren): wird vom <input type="file"> der Seite ausgelöst
 private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
  fileCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
  fileCallback = null
 }

 // Backup als Datei speichern (Speicherort wählt der Nutzer im Android-Dialog)
 private val createBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
  val data = pendingBackup
  pendingBackup = null
  var ok = false
  if (uri != null && data != null) {
   try {
    contentResolver.openOutputStream(uri)?.use { it.write(data.toByteArray(Charsets.UTF_8)) }
    ok = true
   } catch (e: Exception) {
    ok = false
   }
  }
  callJs("onBackupSaved(" + ok + ")")
 }

 // Ordner für die automatische Sicherung wählen (einmalig); Android merkt sich die Berechtigung
 private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
  if (uri == null) {
   callJs("onBackupFolder(false,\"\")")
  } else {
   try {
    contentResolver.takePersistableUriPermission(
     uri,
     Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
    )
    getSharedPreferences(AutoBackup.PREFS, MODE_PRIVATE).edit().putString("folder", uri.toString()).apply()
    callJs("onBackupFolder(true," + JSONObject.quote(AutoBackup.folderLabel(uri)) + ")")
   } catch (e: Exception) {
    callJs("onBackupFolder(false,\"\")")
   }
  }
 }

 // Brücke, die die Seite als "AndroidBridge" sieht
 inner class Bridge {
  @JavascriptInterface
  fun saveBackup(json: String) {
   runOnUiThread {
    pendingBackup = json
    createBackup.launch("macrotrack-backup.json")
   }
  }

  // Automatische Sicherung: schreibt die Datei ohne Dialog (mode: "downloads" oder "folder"); das Ergebnis kommt über onAutoBackup(ok, text)
  @JavascriptInterface
  fun autoBackup(mode: String, json: String, name: String) {
   Thread {
    val res = AutoBackup.write(this@MainActivity, mode, json, name)
    runOnUiThread { callJs("onAutoBackup(" + (res == "ok") + "," + JSONObject.quote(res) + ")") }
   }.start()
  }

  // Ordner-Auswahl für die automatische Sicherung öffnen; das Ergebnis kommt über onBackupFolder(ok, name)
  @JavascriptInterface
  fun pickBackupFolder() {
   runOnUiThread {
    try {
     folderPicker.launch(null)
    } catch (e: Exception) {
     callJs("onBackupFolder(false,\"\")")
    }
   }
  }

  @JavascriptInterface
  fun scanBarcode() {
   runOnUiThread { startScan() }
  }

  // Tägliche Erinnerung ein-/ausschalten (Uhrzeit hour:minute); ab Android 13 wird die Benachrichtigungs-Berechtigung angefragt
  @JavascriptInterface
  fun setReminder(enabled: Boolean, hour: Int, minute: Int) {
   runOnUiThread {
    getSharedPreferences(Reminder.PREFS, MODE_PRIVATE).edit()
     .putBoolean("on", enabled).putInt("h", hour).putInt("m", minute).apply()
    if (enabled) {
     if (android.os.Build.VERSION.SDK_INT >= 33 &&
      checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
     ) {
      requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 502)
     }
     Reminder.schedule(this@MainActivity, hour, minute)
    } else {
     Reminder.cancel(this@MainActivity)
    }
   }
  }

  // Datum (JJJJ-MM-TT), an dem schon etwas eingetragen wurde; an diesem Tag kommt keine Erinnerung
  @JavascriptInterface
  fun setLoggedDate(date: String) {
   getSharedPreferences(Reminder.PREFS, MODE_PRIVATE).edit().putString("logged", date).apply()
  }

  // Öffnet die Android-Einstellungen dieser App (Berechtigungen → Kamera), falls die Kamera gesperrt wurde
  @JavascriptInterface
  fun openAppSettings() {
   runOnUiThread {
    try {
     startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName)))
    } catch (e: Exception) {
    }
   }
  }
 }

 private fun callJs(code: String) {
  web.evaluateJavascript("(function(){try{" + code + "}catch(e){}})()", null)
 }

 private fun startScan() {
  try {
   val options = GmsBarcodeScannerOptions.Builder()
    .setBarcodeFormats(
     Barcode.FORMAT_EAN_13,
     Barcode.FORMAT_EAN_8,
     Barcode.FORMAT_UPC_A,
     Barcode.FORMAT_UPC_E,
     Barcode.FORMAT_CODE_128
    )
    .build()
   GmsBarcodeScanning.getClient(this, options).startScan()
    .addOnSuccessListener { barcode ->
     val raw = barcode.rawValue ?: ""
     callJs("onNativeBarcode(" + JSONObject.quote(raw) + ")")
    }
    .addOnFailureListener {
     callJs("onNativeBarcodeError()")
    }
  } catch (e: Throwable) {
   callJs("onNativeBarcodeError()")
  }
 }

 override fun onCreate(b: Bundle?) {
  super.onCreate(b)
  web = WebView(this)
  web.settings.javaScriptEnabled = true
  web.settings.domStorageEnabled = true
  web.settings.mediaPlaybackRequiresUserGesture = false
  web.addJavascriptInterface(Bridge(), "AndroidBridge")
  web.webChromeClient = object : WebChromeClient() {
   override fun onPermissionRequest(r: PermissionRequest) {
    runOnUiThread {
     if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) r.grant(r.resources)
     else { pending = r; requestPermissions(arrayOf(Manifest.permission.CAMERA), 501) }
    }
   }

   override fun onShowFileChooser(
    view: WebView?,
    callback: ValueCallback<Array<Uri>>?,
    params: WebChromeClient.FileChooserParams?
   ): Boolean {
    fileCallback?.onReceiveValue(null)
    fileCallback = callback
    return try {
     pickFile.launch("*/*")
     true
    } catch (e: Exception) {
     fileCallback = null
     callback?.onReceiveValue(null)
     false
    }
   }
  }
  setContentView(web)
  // Ab Android 15 zeichnet die App unter Status- und Gestenleiste: Abstände auf die Seite übertragen (auch für die Tastatur)
  ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
   val bars = insets.getInsets(
    WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
   )
   v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
   WindowInsetsCompat.CONSUMED
  }
  onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
   override fun handleOnBackPressed() {
    web.evaluateJavascript("(function(){try{return appBack()}catch(e){return false}})()") { r ->
     if (r != "true") finish()
    }
   }
  })
  web.loadUrl("file:///android_asset/index.html")
 }

 override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
  super.onRequestPermissionsResult(c, p, r)
  if (c == 501) {
   if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) pending?.grant(pending?.resources ?: emptyArray()) else pending?.deny()
   pending = null
  }
  if (c == 502 && (r.isEmpty() || r[0] != PackageManager.PERMISSION_GRANTED)) {
   callJs("onNotifDenied()")
  }
 }
}
