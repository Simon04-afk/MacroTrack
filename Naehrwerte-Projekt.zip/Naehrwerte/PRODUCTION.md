# Produktions-Checkliste

## Jetzt vorhanden
- Android-App-Projekt, ausschließlich lokale Datenhaltung, kein Backend, kein Konto
- Datenschutzerklärung passend zur rein lokalen Architektur

## Für den echten Betrieb
- Android Release Signing (eigener Keystore, nicht der Debug-Key aus der CI)
- Echte Geräte-/Regressionstests
- Store-Metadaten und ggf. Play-Store-Eintrag (eigener Google-Play-Console-Account nötig)

## Bewusst nicht mehr relevant
- Alles Backend-/Server-bezogene (Vision-API, Hosting, CORS, JWT, Datenbank) — entfiel mit der Entscheidung, die Foto-Erkennung zu entfernen
