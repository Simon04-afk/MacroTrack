# Status

## Fertig
- [x] Android-Projekt (Kotlin + WebView), einheitliche App-Oberfläche
- [x] Lokale Speicherung, Kalorien/Makros, Tagesziele (validiert), Streak, Wochenübersicht
- [x] Mengenangabe in Gramm, Esslöffel, Teelöffel, Tasse, Milliliter
- [x] Mahlzeiten automatisch nach Tageszeit gruppiert, einzelne Einträge editierbar/entfernbar
- [x] Text-Beschreibung (korrekt case-insensitive, ehrliche "nichts erkannt"-Meldung)
- [x] Lebensmittelsuche: lokale Liste (ca. 960 Einträge, offline) + Open-Food-Facts-Textsuche, mit passendem Symbol
- [x] 50 anpassbare Gerichte (7 Kategorien), eine Sorte je Gericht (Zutaten weglassen/ändern, Mengen, Portionen, Extra-Zutat, Favorit, als Rezept speichern)
- [x] Wasser-Funktion entfernt (auf Wunsch; Cache v14)
- [x] Barcode-Flow über Open Food Facts, kein API-Key nötig
- [x] Barcode ohne Kamera-Einstellungen: Foto-Weg (Kamera-App) mit eigenem EAN-Decoder, Live-Scan auch ohne BarcodeDetector, Knopf „App-Einstellungen öffnen“ in der Android-App (Cache v15; Kotlin-Teil nicht auf dem Gerät getestet)
- [x] „Zuletzt gegessen“ mit ✕ je Eintrag + „Alle entfernen“ + „Rückgängig“; keine Extra-Auswahl „Gerichte“ unter „Essen hinzufügen“ (Cache v16)
- [x] Gerichte löschbar (ausblenden) mit „Rückgängig“ (Cache v17); die Einstellung „Gelöschte Gerichte zurückholen“ ist seit v22 auf Wunsch entfernt
- [x] Gerichte und Rezepte klar getrennt (Richtung „Schnellwahl + Selbstgekocht“): Gerichte = ＋ trägt die Standardportion sofort ein (mit „Rückgängig“), Namen antippen = anpassen; Rezepte = Zubereitungsschritte (Editor mit Zeit je Schritt, Reihenfolge, Löschen) und Kochmodus (ein Schritt groß, Timer je Schritt auch im Hintergrund, Alarm, Display bleibt an) — die 10 vorgefertigten Rezepte haben Schritte (Cache v18; Kochmodus nicht auf dem Gerät getestet)
- [x] Rezepte enthält nur noch Rezepte (Gerichte nur in der Suche); Gerichte-Kategorien Salate, Sandwiches, Suppen, Frühstück & Bowls entfernt (76 → 50 Gerichte); 18 Semmeln aus 7 Supermärkten (REWE, ALDI, Lidl, Kaufland, EDEKA, Netto, Penny; 979 Lebensmittel); Einstellungen im Profil (Erinnerungs-Hinweis an/aus, Mahlzeiten-Zeiten, Gelöschte Gerichte zurückholen) (Cache v19)
- [x] Rezepte importieren: Rezepttext einfügen (Zutaten, Mengen, Schritte, Timer erkannt, Vorschau mit änderbaren Mengen), Datei-Import (.json/.txt/.md) und „Meine Rezepte als Datei sichern“ (Cache v20; getestet im Browser-Modell und per Playwright bei 390/320 px, nicht auf dem Gerät). Die 32 mitgelieferten Vorlagen-Rezepte wurden in v22 auf Wunsch wieder entfernt (unveränderte Kopien werden einmalig mit „Rückgängig“ gelöscht)
- [x] Rezept im Netz suchen: Suchbegriff + Schnellwahl, Suche in Google/Chefkoch/lecker.de im Browser öffnen, kopiertes Rezept per Knopf einfügen (Text-Erkennung wie beim Rezepttext); Parser schneidet Kommentare/ähnliche Rezepte beim Einfügen ganzer Seiten ab (Cache v21; Öffnen der Links in der Android-App nicht auf dem Gerät getestet)
- [x] Taille entfernt, Körperdaten (Größe, Geburtsjahr, Geschlecht, Aktivität) mit BMI, Grundumsatz/Gesamtumsatz nach Formel, Protein pro kg; „Bedarf & Plan“ rechnet nach Formel, solange der gemessene Bedarf noch nicht möglich ist (Cache v23; nicht auf dem Gerät getestet)
- [x] Einstellungen erweitert (v22): Sicherungs-Hinweis (14 Tage) mit Knopf „Sichern“, Wochenstart Montag/Sonntag, Kochmodus-Optionen (Bildschirm, Alarmton, Vibration), „Alle Daten zurücksetzen“ mit Rückfrage; „Gelöschte Gerichte zurückholen“ entfernt (Cache v22; nicht auf dem Gerät getestet)
- [x] v25: Wochen-Check (Ziel-Vorschlag aus gemessenem Bedarf, höchstens 1x/Woche, Übernehmen/Später, in Einstellungen abschaltbar), Schnelltasten im Mengenfenster (Stück/Scheibe/Portion/50-100-200 g), Mahlzeit als Vorlage (Rezept) speichern, Ballaststoffe/Zucker/Natrium in der Analyse (Tag und Ø pro Tag), Android: tägliche Erinnerung als Benachrichtigung (Reminder.kt, nur wenn heute noch nichts eingetragen; Kotlin ungetestet, Build über GitHub Actions)
- [x] Verbesserungsrunde (v24): Live-Vorschau kcal/Makros beim Hinzufügen, zuletzt benutzte Menge je Lebensmittel, kcal je Zeile + Summe bei „Erkannte Lebensmittel“, Lebensmittelnamen statt „1 Eintrag“ in der Mahlzeitenliste, Makro-Summe und „Weiteres Essen hinzufügen“ im Mahlzeit-Fenster, Makro-Legende ohne Umbruch, ausgerichtete Symbole in „Essen hinzufügen“, rundes + nur auf den vier Hauptseiten, kaputte Zahlen in Einträgen werden beim Laden abgefangen (nicht auf dem Gerät getestet)
- [x] v26: v24 und v25 (zweiter Chat) zusammengeführt und mit allen eigenen Tests geprüft (neu `t_v25.js`, `v25.py`); behoben: kaputte Zahlen (`null`) in Einträgen nach dem Neuladen, Android-Erinnerung blieb nach abgelehnter Berechtigung aktiv, letzte Menge akzeptiert nur echte Einheiten (Cache v26; `Reminder.kt` nie kompiliert, nicht auf dem Gerät getestet)
- [x] v27: Rezepte skalieren („Kochen für“ N Portionen, ½×–3×, Gesamtgewicht, optional „Fertiges Gewicht“, „Ich esse“ in Portionen oder Gramm, Kochmodus mit skalierten Mengen), Einkaufsliste (aus Rezept oder Woche, abhaken, kopieren, Rückgängig), Wochenplan (Woche, ＋ je Tag, als gegessen eintragen, Woche kopieren, Einkaufsliste für die Woche), automatische Sicherung für die Android-App (Downloads/MacroTrack oder eigener Ordner, 60 s nach Änderungen und beim Verlassen, neueste 7 Dateien; nicht Teil des Backups). Geprüft per Node-Tests (`t_v27.js`), Playwright bei 390/320 px (`v27.py`) und Monkey-Läufen; Cache v27; `AutoBackup.kt` und die neuen Brücken-Methoden in `MainActivity.kt` nie kompiliert, nicht auf dem Gerät getestet
- [x] Details-Fenster pro Lebensmittel (Produktbild, Nährwerte, Hinweiszeile) und eigene Fotos: Kamera/Galerie → Vorschau → erst „Speichern“ speichert; Entfernen nur nach Rückfrage; Fotos nur lokal, im Backup enthalten
- [x] Eigenes Foto pro Mahlzeit (320 px, IndexedDB mit localStorage-Ersatz, im Backup enthalten); Verlauf-Bildschirm war durch doppelte Element-ID leer → behoben
- [x] Online-Treffer erscheinen mit Symbol; das Produktbild gibt es erst in den Details und wird für gemerkte Produkte offline vorgehalten
- [x] Symbole aller Lebensmittel geprüft (Regelwerk `guessEmoji` + Korrekturliste, automatisch getestet)
- [x] Analyse mit echt umschaltbaren Tag-/Wochen-/Monatsansicht
- [x] Gewichtsverlauf mit Chart
- [x] Backup (Export/Import als JSON)
- [x] Datenschutzerklärung (privacy.html, verlinkt im Profil)
- [x] PWA-Icon korrekt deklariert (any/maskable getrennt) + eigenes Icon für Web und nativen Launcher
- [x] GitHub-Actions-Workflow für APK-Build
- [x] GitHub-Pages-fertige Kopie (`docs/`) für die PWA-Installation

## Bewusst nicht (mehr) enthalten
- Nutzerkonten, Login, Mahlzeiten-Cloud-Sync
- Foto-/Kamera-Erkennung und das dazugehörige Backend — auf Wunsch komplett entfernt; die App braucht dadurch keinen Server mehr

## Noch offen
- [x] Mikronährstoffe, Ballaststoffe/Zucker/Natrium in der Analyse
- [ ] Rezepte, nächste Runde (Idee, noch nicht gebaut): Foto/Zeit/Tags je Rezept (Mengen skalieren, Einkaufsliste und Wochenplan sind seit v27 gebaut)
- [x] Automatische Sicherung (v27, Android)
- [ ] Wochenansicht mit Ziel-Linie/Durchschnitt (nicht gewählt)
- [ ] Online-Rezeptsuche, weitere Stufen (Variante 1 „Suchen und zurückkopieren“ ist seit v21 gebaut; offen: eigene Rezeptpakete auf GitHub Pages mit Suchfeld, „Teilen → MacroTrack“ in der Android-App, Link einfügen; siehe Projektwissen „Rezepte importieren“)
- [ ] Android Release-Keystore + Play-Store-Metadaten
- [ ] Vollständige Geräte-/Regressionstests
