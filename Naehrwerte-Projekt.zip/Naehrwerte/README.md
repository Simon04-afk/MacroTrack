# MacroTrack

Kalorien-/Makro-Tracker als installierbare Android-App bzw. PWA. Läuft vollständig lokal auf dem Gerät — kein Konto, keine Cloud, kein Backend.

## Struktur

### `android/`
Installierbare Android-App (WebView um die HTML/JS-Oberfläche). Barcode-/Text-/Suchen-Flows, lokale Speicherung, eigenes App-Icon.

## Lokal starten
`android/` in Android Studio öffnen und ausführen (Gradle-Wrapper wird beim ersten Sync automatisch vorgeschlagen).

## Funktionen
- Kalorien/Makros (Protein, Kohlenhydrate, Fett) mit Tagesring und Zielen
- Mengenangabe in **Gramm, Esslöffel, Teelöffel, Tasse oder Milliliter**
- Mahlzeiten automatisch nach Tageszeit gruppiert (Frühstück/Mittagessen/Abendessen/Snack), einzelne Einträge nachträglich anpassbar oder entfernbar
- Lebensmittelsuche: ca. 980 feste Einträge (offline; Zutaten und Beilagen, darunter 18 Semmeln aus REWE, ALDI, Lidl, Kaufland, EDEKA, Netto und Penny, Name „Semmel … (Markt)“, mit Stückgewicht und Quelle in den Details; Werte laut Händler-/Datenbankangaben, die Rezeptur kann abweichen) + Live-Suche bei Open Food Facts, mit automatisch passendem Symbol
- Anpassbare Gerichte: 50 Gerichte (Pizza, Burger & Fast Food, Döner & Orient, Mexikanisch, Pasta & Reis, Asiatisch & Indisch, Hauptgerichte; bewusst nur eine Sorte je Gericht; Salate, Sandwiches, Suppen und Frühstück & Bowls wurden auf Wunsch entfernt), die aus Zutaten bestehen. Im Gerichte-Fenster Zutaten per Haken weglassen, Mengen ändern (− / + oder tippen), eigene Zutat hinzufügen, Portionen wählen; Kalorien/Makros rechnen live mit und zeigen den Unterschied zum Standard. Eintragen als Frühstück/Mittag/Abend/Snack oder als eigene Mahlzeit; als Favorit oder als eigenes Rezept speicherbar. Auffindbar nur über die Suche (Suchfeld, „Favoriten“, „Zuletzt gegessen“); bei „Rezepte“ gibt es bewusst nur Rezepte und unter „Essen hinzufügen“ keine eigene Auswahl für Gerichte. In der Suche trägt das ＋ die Standardportion sofort ein (mit „Rückgängig“), auf den Namen tippen öffnet das Anpassen-Fenster. Gerichte lassen sich im Anpassen-Fenster löschen („🗑 Gericht löschen“, mit „Rückgängig“); gelöschte Gerichte werden nur ausgeblendet und lassen sich im Profil unter „Einstellungen → Gelöschte Gerichte“ zurückholen. Werte sind Schätzungen aus den Zutaten
- Details zu jedem Lebensmittel (Tippen auf Name/Symbol): Produktbild, Nährwerte, Hinweiszeile (roh/gekocht, Stückgewicht, Herkunft der Werte) und optional ein eigenes Foto (nur lokal, nur nach ausdrücklicher Bestätigung, im Backup enthalten)
- Eigenes Foto pro Mahlzeit (📷 in der Mahlzeitenliste oder im Mahlzeit-Fenster): Kamera/Galerie → Vorschau → erst „Speichern“ speichert; das Foto erscheint als Vorschaubild in Heute, Verlauf und Tagesliste, damit du die Mahlzeit sofort wiedererkennst. Nur lokal (IndexedDB, Ersatz: localStorage mit kleinerem Limit), im Backup enthalten (die neuesten 100)
- Barcode-Scan über Open Food Facts (kein API-Key nötig): live mit der Kamera, **ohne Einstellungen auch per Foto** (Tippen auf „Foto vom Barcode aufnehmen“ öffnet die normale Kamera-App, der Code wird im Foto gelesen – eingebauter Browser-Leser oder App-eigener Decoder für EAN-13/EAN-8/UPC-A) oder manuell eintippen. In der Android-App liest der Google-Scanner; ist die Kamera gesperrt, führt ein Knopf in die App-Einstellungen
- Text-Beschreibung ("z. B. 150 g Hähnchenbrust und 200 g Reis") — erkennt Mengen direkt aus dem Text (Zahl + Einheit), vor dem Übernehmen einzeln per +/- anpassbar; ohne erkennbare Menge sicherer Rückfall auf 100 g statt einer falschen Kleinstmenge
- Rezepte: 10 vorgefertigte Rezepte (Frühstück/Mittagessen/Abendessen/Snack) direkt nutzbar, durchsuchbar und nach Kategorie filterbar; eigene Rezepte aus der Lebensmitteldatenbank zusammenstellbar und bearbeitbar (auch die vorgeschlagenen); beim Hinzufügen werden alle Zutaten als einzeln anpassbare Posten geloggt
- Rezepte mit Zubereitung: jedes Rezept hat nummerierte Schritte (im Editor hinzufügen, per ▲/▼ verschieben, löschen, optional mit Zeit in Minuten). „👨‍🍳 Kochen“ startet den Kochmodus: ein Schritt groß auf dem Bildschirm, Zurück/Weiter, Zutaten jederzeit einblendbar, Timer je Schritt (läuft auch weiter, wenn man zum nächsten Schritt geht; Alarm per Vibration/Ton/Hinweis, Display bleibt an, soweit das Gerät es erlaubt). Mit „✓ Fertig“ geht es zurück ins Rezept, dort kann man es eintragen. Gerichte dagegen sind die Schnellwahl: ＋ trägt die Standardportion sofort ein
- Rezepte importieren (Rezepte → „⤓ Rezepte importieren“): vier Wege, **ohne fertige Rezeptsammlung** (die 32 mitgelieferten Vorlagen-Rezepte wurden am 25.10. auf Wunsch entfernt; unveränderte Kopien davon werden beim ersten Start von Version 22 einmalig aus den Rezepten gelöscht, mit „Rückgängig“; eigene oder geänderte Rezepte bleiben): 1) **🔎 Rezept im Netz suchen** (seit v21): Suchbegriff oder Schnellwahl (Hähnchen, Fisch, Eier, Quark & Skyr, Linsen, Vegetarisch, Frühstück, Snack), dann öffnet ein Link die Suche (Google, Chefkoch, lecker.de) im Browser; dort Zutaten und Zubereitung kopieren, zurück in die App und „📋 Kopiertes Rezept einfügen“ (sonst Textfeld zum Einfügen von Hand) – die Text-Erkennung übernimmt; 2) **Rezepttext einfügen**: Zutatenliste und Zubereitung aus einer Webseite kopieren – die App erkennt Name, Portionen, Zutaten (Mengen wie ½, 1 EL, 1 Dose (240 g), 2 Eier …, Zeilen mit getrennter Menge und Name) und Schritte (Zeiten wie „6 Minuten“ werden zum Timer), zeigt eine Vorschau mit änderbaren Mengen, nennt nicht erkannte Zutaten und nicht eingerechnete Gewürze, dann „Im Editor öffnen“ und speichern; 3) **Datei auswählen**: .json (eigener Export, Rezeptliste, einzelnes Rezept, auch eine Backup-Datei – Mahlzeiten werden dabei nie ersetzt) oder .txt/.md als Rezepttext; Dateien werden geprüft und bereinigt (Namen, Mengen, Symbole, Schritte); 4) **Meine Rezepte als Datei sichern** (macrotrack-rezepte.json; in der Android-App wird der feste Backup-Dateiname verwendet, bitte umbenennen). Die App lädt selbst nichts aus dem Netz und sendet nichts.
- Gericht erstellen: mehrere Lebensmittel spontan frei kombinieren und unter einem eigenen Namen als eine Mahlzeit loggen, statt sie den festen Kategorien Frühstück/Mittagessen/Abendessen/Snack unterzuordnen — Zutaten dabei wahlweise über Suche, Textbeschreibung, Barcode-Scan oder ein bestehendes Rezept hinzufügbar; optional zusätzlich als wiederverwendbares Rezept speicherbar
- Eigene Lebensmittel erstellbar (Name + Nährwerte pro 100g), dauerhaft gespeichert und danach über die Suche auffindbar
- Rückwirkendes Loggen: Datum und Mahlzeit-Kategorie vor dem Hinzufügen wählbar, nicht nur "jetzt"
- Verlauf nach Tagen gruppiert, jeder Tag/jede Mahlzeit antippbar zum Bearbeiten (Menge ±) oder Löschen — nicht nur für heute, für jeden vergangenen Tag
- Analyse: Kalorienverteilungs-Donut (Protein/Kohlenhydrate/Fett), Trend-Chart passend zum gewählten Zeitraum (Tag/Woche = 7 Tage, Monat = 30 Tage)
- Mikronährstoffe (Vitamin A/C, Kalzium, Eisen, Magnesium, Kalium, Zink, Vitamin D) für ca. 25 gängige Lebensmittel der Grunddatenbank sowie echte Werte von Open Food Facts, wo verfügbar — keine erfundenen Werte für alle Lebensmittel
- Gewichtsverlauf mit Zeitraum-Filtern (1W/1M/3M/6M/1J/Alle), Zielgewicht mit Ziellinie im Chart, Trend (kg/Woche) und verbleibender Distanz zum Ziel
- Streak, Wochenübersicht, Export/Import als JSON-Backup
- Installierbar wie eine App (PWA-Icon, Vollbildmodus, Offline-Cache) oder als native APK

## Echte APK bekommen (ohne Android Studio)

Diese Arbeitsumgebung hat kein Android-SDK/Gradle/Internet — die APK entsteht daher per GitHub Actions (`.github/workflows/ci.yml`):

1. Neues Repository auf GitHub anlegen, diesen Ordner pushen:
   ```bash
   cd MacroTrack && git init && git add . && git commit -m "Initial commit"
   git branch -M main && git remote add origin <deine-repo-url> && git push -u origin main
   ```
2. Repo → **Actions** → Workflow läuft automatisch (~2–4 Min.)
3. Unter **Artifacts** die Datei `macrotrack-debug-apk` herunterladen, aufs Handy übertragen, installieren ("unbekannte Quellen" erlauben)

Debug-APK, reicht zum Installieren/Testen, nicht Play-Store-signiert (siehe PRODUCTION.md).

## Auf dem Handy wie eine App öffnen (PWA, ohne APK)

`docs/` ist eine hostfertige Kopie der Web-Dateien für GitHub Pages:

1. Repo → **Settings → Pages → Deploy from a branch → main / `/docs`** → Save
2. Nach 1–2 Minuten live unter `https://<name>.github.io/<repo>/`
3. Auf dem Handy in Chrome öffnen → Menü (⋮) → **"App installieren"**

`docs/` bei Änderungen manuell mit `android/app/src/main/assets/` synchron halten.

## Bekannte Grenzen / mögliche nächste Schritte
- Keine Foto-Erkennung (bewusst entfernt) — Eingabe läuft über Suche, Barcode oder Textbeschreibung
- Rezepte: Foto, Zeit und Tags je Rezept sind nur eine Idee (noch nicht gebaut). Mengen skalieren, Einkaufsliste, Wochenplan und die automatische Sicherung gibt es seit v27
- Die Android-Erinnerung (`Reminder.kt`, seit v25) und die automatische Sicherung (`AutoBackup.kt`, seit v27) wurden nie kompiliert und nie auf einem Gerät getestet; bei roter CI zuerst `AutoBackup.kt`, `Reminder.kt` und `MainActivity.kt` im Fehlerprotokoll ansehen
- Play-Store-Veröffentlichung: eigener Play-Console-Account + Release-Signing nötig (siehe PRODUCTION.md)

## Fenster-Navigation
Das × in Fenstern geht einen Schritt zurück (Zurück-Schritt) zum vorherigen Fenster; nur beim ersten Fenster wird geschlossen.

## Funktionen (Auszug)
- Suche (offline ~980 Lebensmittel + 50 anpassbare Gerichte + Open Food Facts), Barcode, Textbeschreibung (auch per Sprache, wo vom Browser unterstützt), Rezepte, eigene Gerichte
- Einstellungen im Profil: Erinnerungs-Hinweis auf „Heute“ an/aus; Mahlzeiten-Zeiten (bis wann Frühstück, Mittag, Abend vorgeschlagen werden, danach Snack; Standard 11/16/22 Uhr); Sicherungs-Hinweis an/aus (gelber Hinweis auf „Heute“ mit Knopf „Sichern“, wenn die letzte Sicherung 14 Tage oder älter ist oder noch nie eine gemacht wurde und an mindestens 3 verschiedenen Tagen Mahlzeiten eingetragen wurden); Wochenstart Montag/Sonntag (für die Wochenansicht der Analyse); Kochmodus: Bildschirm anlassen, Alarmton, Vibration einzeln an/aus; **Alle Daten zurücksetzen** (Rückfrage mit Haken, optional vorher Backup; löscht Mahlzeiten, Gewicht, Maße, Körperdaten, Rezepte, Favoriten, gelöschte Gerichte, eigene Lebensmittel, Fotos und Einstellungen, nicht rückgängig zu machen). Die frühere Einstellung „Gelöschte Gerichte zurückholen“ gibt es nicht mehr; ein gelöschtes Gericht holt nur noch „Rückgängig“ direkt nach dem Löschen zurück
- Favoriten und „Zuletzt gegessen“ (jeder Eintrag per ✕ entfernbar, „Alle entfernen“, mit „Rückgängig“; betrifft nur diese Liste, keine Mahlzeiten), Mahlzeiten auf andere Tage kopieren
- Analyse Tag/Woche/Monat mit Bericht, Mikronährstoffe inkl. Ballaststoffe, Zucker, Natrium
- Gewicht mit Trendlinie, Körpermaße (Brust, Hüfte, Oberarm, Oberschenkel, Körperfett; die Taille gibt es seit v23 nicht mehr), **Körperdaten** (Größe, Geburtsjahr, Geschlecht, Aktivität → BMI, gesundes Gewicht, Grundumsatz nach Mifflin-St Jeor, Gesamtumsatz, Protein pro kg), Kalorienbedarf mit Tagesziel-Empfehlung: gemessen aus Essen und Gewichtstrend, solange dafür noch zu wenig Daten da sind nach Formel aus den Körperdaten
- **Schneller eintragen (v24/v25):** im Mengenfenster Live-Vorschau (kcal, P, KH, F), die zuletzt benutzte Menge samt Einheit je Lebensmittel und Schnelltasten (1/2 Stück, 1/2 Scheiben, ½/1 Portion, 50/100/200 g); „Erkannte Lebensmittel“ zeigt kcal je Zeile und die Summe; die Mahlzeitenliste zeigt Lebensmittelnamen; im Mahlzeit-Fenster Makro-Summe, „＋ Weiteres Essen hinzufügen“ und „📋 Als Vorlage (Rezept) speichern“
- **Wochen-Check (v25):** einmal pro Woche schlägt die Karte auf „Heute“ ein neues Kalorienziel vor, wenn der gemessene Bedarf (Essen + Gewichtstrend) mindestens 50 kcal davon abweicht; „Übernehmen“ setzt es (Protein bleibt), „Später“ wartet 7 Tage; in den Einstellungen abschaltbar
- **Ballaststoffe, Zucker, Natrium (v25):** eigene Karte in der Analyse (Tag bzw. Ø pro Tag) gegen die Tagesziele, mit Hinweis, wenn nicht für alle Einträge Werte bekannt sind
- **Tägliche Erinnerung (v25, nur Android-App):** Benachrichtigung zur gewählten Uhrzeit (Standard aus, 19:00), nur wenn heute noch nichts eingetragen ist; ab Android 13 fragt die App nach der Berechtigung; nach einem Neustart des Handys wird sie neu eingeplant
- **Rezepte skalieren (v27):** im Rezept „Kochen für“ N Portionen (Tasten ½×/1×/2×/3×): Mengen, Gesamtgewicht und kcal werden umgerechnet, ohne das Rezept zu ändern; der Kochmodus nutzt die skalierten Mengen. Optional „Fertiges Gewicht“ im Editor (z. B. nach dem Kochen gewogen): „Ich esse“ geht dann in Portionen **oder Gramm** (kcal je 100 g, 250 g Haferbrei usw.)
- **Einkaufsliste (v27):** „🛒 Einkaufsliste“ auf der Rezepte-Seite; Zutaten eines Rezepts (in der gewählten Portionenzahl) oder einer ganzen Woche, gleiche Zutaten werden addiert; abhaken, ✕, eigene Einträge, „Liste kopieren“ (Teilen/Zwischenablage), „Erledigte entfernen“ mit „Rückgängig“
- **Wochenplan (v27):** „📅 Wochenplan“ auf der Rezepte-Seite; Woche mit ＋ je Tag, Rezept suchen, Portionen und Mahlzeit wählen; „Als gegessen eintragen“ (mit „Rückgängig“), „Einkaufsliste für diese Woche“, „Woche in die nächste kopieren“; auch aus dem Rezept („In den Wochenplan“); Plan und Liste sind im Backup enthalten
- **Automatische Sicherung (v27, nur Android-App):** Einstellungen → „Automatische Sicherung“: Aus / **Downloads** (Ordner `Downloads/MacroTrack`, ohne Rückfrage) / **Eigener Ordner** (einmal wählen, wird gemerkt). Rund 60 Sekunden nach einer Änderung und beim Verlassen der App wird `MacroTrack-Sicherung-JJJJ-MM-TT.json` geschrieben (je Tag eine Datei, die neuesten 7 bleiben). Wiederherstellen über „Import“. Die Einstellung gilt nur für dieses Gerät und steht nicht im Backup; ein erfolgreiches Sichern setzt den Sicherungs-Hinweis zurück

## Versionsstand
- **v22:** erweiterte Einstellungen, 32 Vorlagen-Rezepte entfernt, „Alle Daten zurücksetzen“
- **v23:** Taille entfernt, Körperdaten, Bedarf nach Formel
- **v24, v25:** Verbesserungsrunde, Wochen-Check, Schnelltasten, Nährstoffe-Karte, Android-Erinnerung (zweiter Chat im Projekt)
- **v26:** v24/v25 zusammengeführt und mit allen Tests geprüft; behoben: kaputte Zahlen (`null`) nach dem Neuladen, Erinnerung blieb nach abgelehnter Berechtigung in der Android-App aktiv
- **v27:** Rezepte skalieren + Gesamtgewicht + Gramm-Modus, Einkaufsliste, Wochenplan, automatische Sicherung (Android; `AutoBackup.kt` neu, `MainActivity.kt` erweitert; Cache v27)
- Bei Änderungen an der Oberfläche hochladen: `docs/index.html`, `docs/sw.js`, `android/app/src/main/assets/index.html`, `android/app/src/main/assets/sw.js`; bei Änderungen an der Android-App außerdem `android/app/src/main/java/com/naehrwerte/app/MainActivity.kt`, `AutoBackup.kt`, `Reminder.kt`, `android/app/src/main/res/drawable/ic_stat_ring.xml` und `android/app/src/main/AndroidManifest.xml`
